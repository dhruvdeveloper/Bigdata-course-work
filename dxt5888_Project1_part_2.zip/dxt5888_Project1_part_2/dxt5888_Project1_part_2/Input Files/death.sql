
CREATE TABLE `deaths` (
  `State` varchar(50) NOT NULL,
  `County` varchar(50) NOT NULL,
  `ReportDate` varchar(15) NOT NULL,
  `DeahCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`State`,`County`,`ReportDate`),
  KEY `County` (`County`),
  CONSTRAINT `deaths_ibfk_1` FOREIGN KEY (`State`) REFERENCES `state` (`State`),
  CONSTRAINT `deaths_ibfk_2` FOREIGN KEY (`County`) REFERENCES `county` (`County`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
