
CREATE TABLE `confirmed_case` (
  `State` varchar(50) NOT NULL,
  `County` varchar(50) NOT NULL,
  `TestDate` varchar(15) NOT NULL,
  `PositiveCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`State`,`County`,`TestDate`),
  KEY `County` (`County`),
  CONSTRAINT `confirmed_case_ibfk_1` FOREIGN KEY (`State`) REFERENCES `state` (`State`),
  CONSTRAINT `confirmed_case_ibfk_2` FOREIGN KEY (`County`) REFERENCES `county` (`County`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

