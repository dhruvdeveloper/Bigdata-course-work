
CREATE TABLE `county` (
  `State` varchar(50) DEFAULT NULL,
  `County` varchar(50) NOT NULL,
  `Population` int(11) DEFAULT NULL,
  `Latitude` varchar(25) NOT NULL,
  `Longitude` varchar(25) NOT NULL,
  PRIMARY KEY (`County`,`Latitude`,`Longitude`),
  KEY `State` (`State`),
  CONSTRAINT `county_ibfk_1` FOREIGN KEY (`State`) REFERENCES `state` (`State`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

