
CREATE TABLE `state` (
  `State_id` int(10) NOT NULL AUTO_INCREMENT,
  `State` varchar(50) NOT NULL,
  `Abbreviation` char(2) DEFAULT NULL,
  `YearOfStatehood` int(11) DEFAULT NULL,
  `Capital` varchar(50) DEFAULT NULL,
  `Capital_Since` int(11) DEFAULT NULL,
  `LandArea` decimal(10,0) DEFAULT NULL,
  `IsPopulousCity` tinyint(1) DEFAULT NULL,
  `MunicipalPopulatiion` int(20) DEFAULT NULL,
  `MetroPopulatiion` int(20) DEFAULT NULL,
  PRIMARY KEY (`State`),
  KEY `State_id` (`State_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

