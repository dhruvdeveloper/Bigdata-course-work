package temp.temp2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class Temp {


    public static void main (String args[])
    {
        int a[] = {1, 2, 5, 6, 7, 7};
        System.out.println(temp(a));
    }
    public static List<Integer> temp(int a[]){
        Arrays.sort(a);
        HashSet<Integer> hh = new HashSet<>();
        for (int at :
                a) {
            hh.add(at);
        }
        Object[] b = hh.toArray();
        ArrayList<Integer> aa = new ArrayList<>();
        aa.add((int) b[b.length - 1]);
        aa.add((int) b[b.length - 2]);
        aa.add((int) b[b.length - 3]);
        return aa;
    }
}
