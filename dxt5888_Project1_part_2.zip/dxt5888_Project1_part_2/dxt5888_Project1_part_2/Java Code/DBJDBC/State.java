package temp.temp2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.sql.*;

public class State {
    public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, SQLException, InterruptedException {
        final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
        final String DB_URL = "jdbc:mysql://acadmysqldb001p.uta.edu/dxt5888";
        //  Database credentials
        final String USER = "dxt5888";
        final String PASS = "Cse5330@97";
        Connection conn = null;
        Statement stmt = null;
        Class.forName("org.mariadb.jdbc.Driver");
        //STEP 3: Open a connection
        System.out.println("Connecting to a selected database...");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        System.out.println("Connected database successfully...");

        //STEP 4: Execute a query
        System.out.println("Inserting records into the table...");
        stmt = conn.createStatement();

//        String sql = "INSERT INTO state " +
//                "VALUES ('2', 'Texas', 'AL', '1819', 'Montgomery', '1846', '155.4', '0', '205764', '374536')";
////        stmt.executeUpdate(sql);

        Scanner sc = new Scanner(new File("C:\\Users\\Dhruv Thakkar\\Downloads\\001_Project1_Data\\US_state.csv"));
        sc.useDelimiter(",");   //sets the delimiter pattern
        StringBuilder sb = new StringBuilder();
        while (sc.hasNext())  //returns a boolean value
        {
            /*String data[] = sc.next().split("\n");
            for (String a :
                    data) {
                System.out.println(a);
            }*/
            sb.append(sc.next()+":");
//            System.out.print(sc.next() + " | ");  //find and returns the next complete token from this scanner
        }
        String row[] = sb.toString().split("\n");
        for (int i = 1; i < row.length; i++){
            String[] attributeValue = row[i].split(":");
            //System.out.println(row[i]);
//            System.out.println(attributeValue[1]);
            StringBuilder intoSQL = new StringBuilder();
            intoSQL.append("INSERT INTO state VALUES (");
            for (int j = 0; j < attributeValue.length; j++) {
                if (attributeValue[j] == null){
                    attributeValue[j] = "";
                }
                if (j == 7){
                    if (attributeValue[7].equals("Yes")){
                        intoSQL.append("'").append("1");
                    }
                    else {
                        intoSQL.append("'").append("0");
                    }
                }
                else {
                    intoSQL.append("'").append(attributeValue[j]);
                }
//                System.out.println(intoSQL.toString());
                if (j == attributeValue.length - 1){
                    System.out.println(intoSQL.toString());
                    intoSQL.append("');");
                    stmt.executeUpdate(intoSQL.toString());
                }
                intoSQL.append("', ");
            }
        }
//      System.out.println(sb.toString());
        sc.close();  //closes the scanner
    }
}
