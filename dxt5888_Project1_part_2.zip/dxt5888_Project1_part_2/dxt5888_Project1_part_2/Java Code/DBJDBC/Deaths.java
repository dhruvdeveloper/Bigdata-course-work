package temp.temp2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.sql.*;

public class Deaths {
    public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, SQLException, InterruptedException {
        final String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
        final String DB_URL = "jdbc:mysql://acadmysqldb001p.uta.edu/dxt5888";
        //  Database credentials
        final String USER = "dxt5888";
        final String PASS = "Cse5330@97";
        Connection conn = null;
        Statement stmt = null;
        Class.forName("org.mariadb.jdbc.Driver");
        //STEP 3: Open a connection
        System.out.println("Connecting to a selected database...");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        System.out.println("Connected database successfully...");

        //STEP 4: Execute a query
        System.out.println("Inserting records into the table...");
        stmt = conn.createStatement();

//        String sql = "INSERT INTO state " +
//                "VALUES ('2', 'Texas', 'AL', '1819', 'Montgomery', '1846', '155.4', '0', '205764', '374536')";
////        stmt.executeUpdate(sql);

        Scanner sc = new Scanner(new File("C:\\Users\\Dhruv Thakkar\\Downloads\\001_Project1_Data\\Us_deaths1.csv"));
        sc.useDelimiter(",");   //sets the delimiter pattern
        StringBuilder sb = new StringBuilder();
        while (sc.hasNext())  //returns a boolean value
        {
            /*String data[] = sc.next().split("\n");
            for (String a :
                    data) {
                System.out.println(a);
            }*/
            sb.append(sc.next()+":");
//            System.out.print(sc.next() + " | ");  //find and returns the next complete token from this scanner
        }
        String row[] = sb.toString().split("\n");
        String[] attributeValueFirst = row[0].split(":");

        /*ArrayList<String> avf = new ArrayList<>();
        avf.addAll(Arrays.asList(attributeValueFirst));


        String[] attributeValue = row[1].split(":");
        ArrayList<String> av = new ArrayList<>();
        av.addAll(Arrays.asList(attributeValueFirst));*/


        for (int i = 1; i < row.length - 1; i++){
            String[] attributeValue = row[i].split(":");
            //System.out.println(row[i]);
//            System.out.println(attributeValue[1]);
            String intoSQL = new String();

            for (int j = 2; j < 360; j++) {
                intoSQL += "INSERT INTO deaths VALUES ( '";
                intoSQL += attributeValue[0] + "', " +
                        "'" +  attributeValue[1] + "',";
//                System.out.println(attributeValueFirst[0]);
                intoSQL += "'" + attributeValueFirst[j] + "', ";
                intoSQL += "'" + attributeValue[j];

                intoSQL += "');";
                System.out.println(intoSQL.toString());
                stmt.executeUpdate(intoSQL.toString());
                intoSQL = "";
                /*if (j == attributeValue.length - 1){
//                    System.out.println(intoSQL.toString());
                }
                intoSQL += "', ";*/
            }
        }
//      System.out.println(sb.toString());
        sc.close();  //closes the scanner
    }
}
