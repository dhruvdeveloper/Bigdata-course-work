
CREATE TABLE `vaccinations` (
  `State` varchar(50) NOT NULL,
  `TotalDistributed` int(11) DEFAULT NULL,
  `TotalAdministered` int(11) DEFAULT NULL,
  `Distributed per 100K` int(11) DEFAULT NULL,
  `Administered per 100K` int(11) DEFAULT NULL,
  `People with 1+ Doses` int(11) DEFAULT NULL,
  `People with 1+ Doses per 100K` int(11) DEFAULT NULL,
  `People with 2+ Doses` int(11) DEFAULT NULL,
  `People with 2+ Doses per 100K` int(11) DEFAULT NULL,
  PRIMARY KEY (`State`),
  CONSTRAINT `vaccinations_ibfk_1` FOREIGN KEY (`State`) REFERENCES `state` (`State`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
